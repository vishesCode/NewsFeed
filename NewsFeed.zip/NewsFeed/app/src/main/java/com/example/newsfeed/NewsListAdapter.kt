package com.example.newsfeed

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class NewsListAdapter(private val items: ArrayList<String>, private val listener: MainActivity): RecyclerView.Adapter<NewsViewHolder>() {
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): NewsViewHolder {
        val view=LayoutInflater.from(p0.context).inflate(R.layout.item_news,p0,false)
        val viewHolder=NewsViewHolder(view)
        view.setOnClickListener{
            listener.onItemClicked(items[viewHolder.adapterPosition])
        }
        return NewsViewHolder(view)
    }

    override fun onBindViewHolder(p0: NewsViewHolder, p1: Int) {
        val currItem=items[p1]
        p0.titleView.text=currItem
    }

    override fun getItemCount(): Int {
        return items.size
    }
}
class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
      val titleView: TextView =itemView.findViewById(R.id.title)
}
interface NewsItemClicked{
    fun onItemClicked(item: String)
}