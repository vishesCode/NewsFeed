package com.example.newsfeed

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView.layoutManager=LinearLayoutManager(this)
        val items=fetch()
        val adapter:NewsListAdapter=NewsListAdapter(items,this)
        recyclerView.adapter=adapter
    }
    private fun fetch(): ArrayList<String> {
        val list=ArrayList<String>()
        for(i in 0..100){
            list.add("item $i")
        }
        return list
    }

    fun onItemClicked(s: String) {
        Toast.makeText(this,"item is $s",Toast.LENGTH_LONG).show()
    }
}